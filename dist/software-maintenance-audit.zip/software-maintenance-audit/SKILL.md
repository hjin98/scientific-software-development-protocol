---
name: software-maintenance-audit
description: Use to audit a long-lived scientific/technical code base for maintainability risk - hotspots, architectural entropy, weak tests, duplicated authority, dependency or evidence drift. Reports and routes findings; does not refactor.
---

# Software Maintenance Audit

Optional non-authoritative longitudinal sensing specialist. Determine whether a repository/subsystem is becoming harder to reason about, weakly protected, or structurally fragile; prioritize semantic risk concentration rather than static ugliness or arbitrary scores.

**Version entry check.** This package is SSDP `6.6.0`. If the task or its governing workplan declares a different SSDP `protocol_version`, say so and resolve that version's compatible source before protocol-dependent reasoning ([Protocol versioning and compatibility](references/protocol-versioning-and-compatibility.md)); never apply this package's doctrine to other-version work. No declared version: continue.

## Routing

Before substantive audit reasoning read [Abstraction, concretization, authority, challenge, and representation](references/abstraction-and-concretization.md) and [Long-horizon code health](references/long-horizon-code-health.md).

Load only triggered concerns: architecture/ownership/complexity -> [Architecture and design](references/architecture-and-design.md); testing/oracle strength -> [Testing and validation](references/testing-and-validation.md); evidence staleness/dependency/history -> [Evidence, evolution, and semantic dependencies](references/evidence-evolution-and-dependencies.md); materially recurring failure, demonstrated reusable success, preservation capability, discovery, or current notice whose project history may improve later decisions -> [Project Engineering Memory](references/project-engineering-memory.md); lifecycle/rework -> [Workflow and workplans](references/workflow-and-workplans.md); history/churn/change coupling -> [Git and version control](references/git-and-version-control.md); repository inspection/context economy -> [Repository intake](references/repository-intake.md); specialized analyzer relation -> [Tool-assisted engineering](references/tool-assisted-engineering.md); recurrence/family/revision economy -> [Convergence and development-cycle economy](references/convergence-and-cycle-economy.md); documentation coherence -> [Documentation and evidence](references/documentation-and-evidence.md); scientific/numerical correctness/oracles -> [Scientific software](references/scientific-software.md); version-specific history -> [Protocol versioning and compatibility](references/protocol-versioning-and-compatibility.md).

Ordinary hyperlinks/package membership are not activation commands.

## Audit method

Use trustworthy version-control/history evidence when available; state the window and limitations. If history is unavailable, do not infer trends from a static snapshot.

Material signals include combinations of high churn, complexity, weak tests, change coupling, duplicated/synchronized representations, competing owners, dependency cycles/boundary erosion, wrapper/fallback/special-case accumulation, public/config/state growth, stale compatibility/migrations, recurring defect families, weak scientific/numerical oracles, stale evidence, and documentation that needs growing historical caveats to explain present truth.

Metrics are sensors, not verdicts. No universal complexity/coverage/mutation/churn threshold is protocol authority. Investigate the semantic owner and protected outcome before recommending work.

Classify each material finding by the smallest owning repair:

- equivalent local D4 repair/simplification -> `software-implementation`;
- substantial maintenance contract or accepted D3 concern -> `software-design`;
- D2/D1 defect -> route upstream to that authority;
- test/evidence weakness -> owning semantic role under the current/new workplan;
- documentation drift -> `software-documentation`;
- lifecycle/repository residue -> `repository-hygiene`;
- insufficient evidence -> WATCH rather than invented action.

A maintenance finding may become a PEM candidate only when the PEM admission threshold and evidence/counterevidence requirements are actually satisfied. The audit does not mint family identity, recurrence, maturity, temperature, positive preference, or authority by assertion; keep a one-off local finding local unless evidence justifies durable project learning.

Do not redesign or broadly refactor inside the audit. Apply the Lossless Representation Rule to the report: consolidate manifestations under root causes, lead with high-consequence findings, avoid replaying the full history, and keep enough evidence/provenance for each finding to be falsifiable and actionable.

## Output

Conclude with **HEALTHY**, **WATCH**, or **ACTION REQUIRED**. For each material finding give affected subsystem, evidence/trend, authority implication, smallest justified corrective scope, and expected risk/simplicity improvement. Prefer one coherent repair for a shared cause over one workplan per symptom. When a finding materially updates an existing PEM family/notice or meets admission threshold for a new candidate, identify that closeout-learning consequence explicitly without treating it as accepted authority.
