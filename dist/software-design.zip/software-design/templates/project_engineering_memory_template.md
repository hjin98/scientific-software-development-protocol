---
memory_schema_version: 1
maintained_under_protocol: REPLACE_WITH_GOVERNING_PROTOCOL_VERSION
project_id: REPLACE_WITH_STABLE_PROJECT_ID
repository: REPLACE_WITH_REPOSITORY_OR_PROJECT_IDENTITY
scope: repository
coverage_state: UNINITIALIZED
coverage_basis: "No historical backfill has been claimed."
reconciled_through: REPLACE_WITH_ALREADY_EXISTING_ACCEPTED_PROJECT_IDENTITY
accepted_base:
  project_state: REPLACE_WITH_EXACT_ACCEPTED_PROJECT_COMMIT
  basis: REPLACE_WITH_ACCEPTED_PROJECT_MEMORY_BASIS_DESCRIPTION
candidate_overlay: NONE
detail_files: []
---

# Project Engineering Memory

This is compact project-local engineering memory, not D1-D4 semantic authority. Current owners define what must be true; this file records evidence-backed lessons and routes to their warrant. Missing or partial memory never proves that no relevant historical lesson exists.

## Active summary

<!-- BEGIN DERIVED PEM SUMMARY -->
_No current entries._
<!-- END DERIVED PEM SUMMARY -->

## Families

Add a family only when the current PEM admission threshold is met. Keep one canonical fenced `yaml pem-family` record beneath each family heading. Do not copy this explanatory example into a live memory unchanged.

### FF-001 — Example failure family

```yaml pem-family
id: FF-001
kind: FAILURE_FAMILY
state: CURRENT
maturity: PROVISIONAL
temperature: UNASSESSED
summary: Replace with one bounded evidence-backed lesson.
semantic_identity:
  invariant_or_claim: Replace with the governing bounded invariant or claim.
  owner_class: Replace with the current semantic owner class.
  mechanism_family: Replace with the repair-relevant failure mechanism.
  applicability_dimensions: Replace with material regime dimensions.
aggregation_scope: Replace with the bounded aggregation regime.
coverage_state: PARTIAL
coverage_basis: Replace with reviewed sources/surfaces/range and material blind spots.
applicability:
  - replace-with-searchable-owner-surface-mechanism-or-regime-cue
authority_binding: EVIDENCE_ONLY
# If changed to AUTHORITY_BOUND, also provide:
# authority_owner: owner/project@IMMUTABLE_OWNER_REVISION:path/to/governing-owner.md#stable-section
# authority_evidence:
#   - owner/project@ACCEPTED_PROJECT_REVISION:path/to/authority-evidence.md#stable-section
guidance_level: OBSERVED
relations: []
occurrences:
  - id: O01
    event_identity: REPLACE_WITH_IMMUTABLE_EVENT_IDENTITY
    lifecycle_context: qualification
    source_project: local
    surfaces:
      - replace-with-affected-surface
    observation: Replace with the observation; do not rewrite it to match later interpretation.
    cause_claim: Replace with bounded causal interpretation or mark unknown/provisional.
    cause_evidence:
      - REPLACE_WITH_IMMUTABLE_EVIDENCE_ROUTE
    repair: REPLACE_WITH_IMMUTABLE_REPAIR_IDENTITY_OR_NONE
    repair_acceptance: REPLACE_WITH_ACCEPTANCE_IDENTITY_OR_NONE
    provenance_cluster: REPLACE_WITH_CLUSTER_OR_NONE
    # When recurrence_after_accepted_repair is true, add:
    # recurrence_after_accepted_repair: true
    # recurrence_basis:
    #   prior_occurrence_id: O00
    #   repair_identity: commit:IMMUTABLE_REPAIR_SHA
    #   repair_acceptance_evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
    #   later_event_identity: commit:IMMUTABLE_LATER_EVENT_SHA
    #   independence_basis: "Why this is a materially independent later event"
    #   # alias_of: optional-known-alias-identity
    assessments:
      - id: AS01
        state: ADMISSIBLE
        conclusion: CONFIRMED
        evidence:
          - REPLACE_WITH_IMMUTABLE_EVIDENCE_ROUTE
```
  # Optional only for evidence-bound same-ID editorial/narrowing changes that remain within the accepted envelope.
  # Changes to kind, owner_class, or mechanism_family require a new/reclassified identity and lineage instead.
  # semantic_reconciliation:
  #   classification: WITHIN_ENVELOPE
  #   previous_identity_sha256: "64-hex digest of prior kind + semantic_identity + applicability"
  #   reason: "Why this is not a material identity change"
  #   evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]


### SP-001 — Example success pattern

```yaml pem-family
id: SP-001
kind: SUCCESS_PATTERN
state: CURRENT
maturity: PROVISIONAL
temperature: UNASSESSED
summary: Replace with one bounded evidence-backed positive lesson.
semantic_identity:
  invariant_or_claim: Replace with the exact bounded benefit claim.
  owner_class: Replace with current semantic owner class.
  mechanism_family: Replace with the learned engineering mechanism/pattern.
  applicability_dimensions: Replace with material regime dimensions.
aggregation_scope: Replace with the bounded aggregation regime.
coverage_state: PARTIAL
coverage_basis: Replace with favorable and unfavorable history searched plus blind spots.
applicability:
  - replace-with-searchable-applicability-cue
authority_binding: EVIDENCE_ONLY
# If changed to AUTHORITY_BOUND, also provide:
# authority_owner: owner/project@IMMUTABLE_OWNER_REVISION:path/to/governing-owner.md#stable-section
# authority_evidence:
#   - owner/project@ACCEPTED_PROJECT_REVISION:path/to/authority-evidence.md#stable-section
guidance_level: OBSERVED
positive_guidance_eligible: false
# Required before positive_guidance_eligible becomes true:
# counterevidence_search:
#   state: COMPLETE_FOR_DECLARED_SCOPE
#   scope: "Bounded aggregation/coverage scope searched"
#   search_basis: "History/evidence search performed"
#   outcomes_reviewed: [SUPPORTING, NEUTRAL, CONTRADICTING, INCONCLUSIVE]
#   blind_spots: "Material unsearched history or 'none known within declared scope'"
#   evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
#
# For PREFERRED/DEFAULT/BEST use either a typed comparative_basis:
# comparative_basis:
#   comparison_set: [technique-a, technique-b]
#   comparator: technique-b
#   objective: governing objective
#   constraints: [material constraint]
#   evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
#   provenance_state: INDEPENDENT
#   minimum_independent_clusters: 2
# or accepted-owner comparative_authority.
comparative_basis: NONE
relations: []
applications:
  - id: A01
    episode_identity: REPLACE_WITH_IMMUTABLE_INTERVENTION_IDENTITY
    lifecycle_context: qualification
    source_project: local
    surfaces:
      - replace-with-affected-surface
    provenance_cluster: REPLACE_WITH_CLUSTER_OR_NONE
    subject: REPLACE_WITH_SUBJECT
    comparator: REPLACE_WITH_COMPARATOR_OR_NONE
    intended_benefit: REPLACE_WITH_BOUNDED_BENEFIT
    outcome: SUPPORTING
    observation: Replace with the observed outcome.
    quantitative_effect: REPLACE_WITH_EFFECT_OR_NONE
    uncertainty: REPLACE_WITH_UNCERTAINTY_OR_NONE
    costs_tradeoffs: REPLACE_WITH_COSTS_OR_NONE
    assessments:
      - id: AS01
        state: ADMISSIBLE
        conclusion: SUPPORTS_BOUNDED_CLAIM
        evidence:
          - REPLACE_WITH_IMMUTABLE_EVIDENCE_ROUTE
```

When a later assessment replaces an earlier current interpretation, append it with explicit lineage rather than relying on list order, for example `supersedes: [AS01]`. If competent assessments remain materially conflicting, preserve both as live or append an explicit `REVIEW_REQUIRED` adjudication that supersedes the resolved prior state; do not use latest-editor position or vote count as current truth.

## Current notices

Use notices only for high-impact current facts that are not yet honest generalized families. Current notices use typed, evaluable triggers. For an accepted-base/owner/binding-change trigger, capture the admitted basis when the notice is created; do not replace it with opaque prose. If `normative_status` is authority-bound, `owner` is an immutable governing-owner route and the notice evidence must resolve inside the accepted project state; otherwise keep the notice non-authoritative/review-required.

### NT-001 — Example current notice

```yaml pem-notice
id: NT-001
state: REVIEW_REQUIRED
summary: Replace with bounded current fact.
normative_status: NON_AUTHORITATIVE
owner: NONE
applicability:
  - replace-with-applicability-cue
binding_health: REVIEW_REQUIRED
evidence:
  - REPLACE_WITH_IMMUTABLE_EVIDENCE_ROUTE
review_trigger:
  type: accepted_base_change
  basis: REPLACE_WITH_EXACT_ACCEPTED_BASE_AT_NOTICE_ADMISSION
```

## Historical Applicability Set handoff shape

A workplan that triggers PEM records the exact basis used; this block normally belongs in that workplan/handoff rather than in the project memory itself. These three basis fields are the canonical executable interface; do not substitute `accepted_base`, `candidate_overlay`, or another translation alias.

```yaml pem-has
pem_basis:
  accepted_project_state: REPLACE_WITH_EXACT_ACCEPTED_PROJECT_STATE
  accepted_pem: REPLACE_WITH_EXACT_ACCEPTED_PEM_PUBLICATION_OR_NONE
  candidate_overlay_semantic_candidate: REPLACE_WITH_EXACT_CANDIDATE_OR_NONE
has:
  - id: FF-001
    disposition: REVIEW_REQUIRED
    reason: Replace with bounded current-task reason.
```

If the accepted memory basis materially advances before integration/closeout, reconcile the changed interval/surfaces and refresh the HAS rather than silently keeping the old decision.


## Claim-relative maturity and temperature examples

A `PROVEN` record includes structured `maturity_basis`; do not use a top-level independence flag to change claim obligations.

```yaml
maturity_basis:
  claim: "Exact bounded claim asserted as PROVEN"
  obligations:
    - type: claim_support
      status: CLOSED
      evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
    - type: applicability
      status: CLOSED
      evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
    - type: contradiction_resolution
      status: CLOSED
      evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
```

When declared temperature intentionally differs from its derived base:

```yaml
temperature_override:
  final: HOT
  reason: "Evidence-backed impact/salience reason"
  evidence: [SOURCE@IMMUTABLE_ID:path#stable-locator]
```
